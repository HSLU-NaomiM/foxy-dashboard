const UploadModal = ({ isOpen, onClose, headers, data, onUploadConfirm, fileName, onDatabaseSelect, selectedDatabase, onSeparatorSelect, selectedSeparator }) => {
    const [selectedMappings, setSelectedMappings] = useState({});
    const [uploadStatus, setUploadStatus] = useState('');

    const targetColumns = databaseSchemas[selectedDatabase] || [];

    useEffect(() => {
        if (isOpen) {
            const initialMappings = {};
            targetColumns.forEach(targetCol => {
                const matchedHeader = headers.find(header => header.toLowerCase() === targetCol.toLowerCase());
                if (matchedHeader) {
                    initialMappings[targetCol] = matchedHeader;
                } else {
                    initialMappings[targetCol] = '';
                }
            });
            setSelectedMappings(initialMappings);
            setUploadStatus('');
        }
    }, [isOpen, headers, data, selectedDatabase, targetColumns]);

    if (!isOpen) return null;

    const handleMappingChange = (targetColumn, sourceColumn) => {
        setSelectedMappings(prev => ({
            ...prev,
            [targetColumn]: sourceColumn
        }));
    };

    const handleUpload = async () => {
        setUploadStatus('loading');
        const dataToUpload = data.map(row => {
            const newRow = {};
            for (const targetCol of Object.keys(selectedMappings)) {
                const sourceCol = selectedMappings[targetCol];
                if (sourceCol) {
                    const value = row[sourceCol];
                    if (['machine_revenue', 'amount', 'quantity'].includes(targetCol)) {
                        const numericValue = parseFloat(value);
                        newRow[targetCol] = isNaN(numericValue) ? null : numericValue;
                    } else {
                        newRow[targetCol] = value !== undefined ? value : null;
                    }
                }
            }
            return newRow;
        });
        try {
            const { data: insertedData, error } = await onUploadConfirm(dataToUpload, selectedDatabase);
            if (error) {
                console.error('Supabase upload error:', error);
                setUploadStatus(`error: ${error.message}`);
            } else {
                setUploadStatus('success');
                setTimeout(() => {
                    onClose();
                }, 2000);
            }
        } catch (err) {
            console.error('Upload confirmation failed:', err);
            setUploadStatus(`error: ${err.message}`);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg p-6 max-w-4xl w-full shadow-xl">
                <div className="flex justify-between items-center mb-4 border-b pb-3">
                    <h3 className="text-2xl font-bold text-gray-800">Upload Data: {fileName}</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>

                {uploadStatus === 'loading' && (
                    <div className="flex items-center justify-center p-4 text-blue-600">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mr-2"></div>
                        Uploading data...
                    </div>
                )}
                {uploadStatus.startsWith('error') && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                        <strong className="font-bold">Upload Failed!</strong>
                        <span className="block sm:inline"> {uploadStatus.substring(6)}</span>
                    </div>
                )}
                {uploadStatus === 'success' && (
                    <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                        <strong className="font-bold">Success!</strong>
                        <span className="block sm:inline"> Data uploaded successfully.</span>
                    </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div>
                        <label htmlFor="database-select" className="text-sm font-medium text-gray-700 mb-1 block">
                            Select Database Table:
                        </label>
                        <select
                            id="database-select"
                            value={selectedDatabase}
                            onChange={(e) => onDatabaseSelect(e.target.value)}
                            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md shadow-sm"
                        >
                            {Object.keys(databaseSchemas).map(dbName => (
                                <option key={dbName} value={dbName}>
                                    {dbName.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="separator-select" className="text-sm font-medium text-gray-700 mb-1 block">
                            CSV Separator:
                        </label>
                        <select
                            id="separator-select"
                            value={selectedSeparator}
                            onChange={(e) => onSeparatorSelect(e.target.value)}
                            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md shadow-sm"
                        >
                            <option value=",">Comma (,)</option>
                            <option value=";">Semicolon (;)</option>
                            <option value="\t">Tab (\t)</option>
                            <option value="|">Pipe (|)</option>
                        </select>
                    </div>
                </div>

                <h4 className="text-lg font-semibold text-gray-700 mb-3">Column Mapping for "{selectedDatabase.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}"</h4>
                <div className="grid grid-cols-2 gap-4 mb-6 max-h-60 overflow-y-auto pr-2">
                    {targetColumns.length > 0 ? (
                        targetColumns.map(targetCol => (
                            <div key={targetCol} className="flex flex-col">
                                <label htmlFor={`map-${targetCol}`} className="text-sm font-medium text-gray-700 mb-1">
                                    Map to Supabase "{targetCol}"
                                </label>
                                <select
                                    id={`map-${targetCol}`}
                                    value={selectedMappings[targetCol] || ''}
                                    onChange={(e) => handleMappingChange(targetCol, e.target.value)}
                                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md shadow-sm"
                                >
                                    <option value="">-- Ignore this column --</option>
                                    {headers.map(header => (
                                        <option key={header} value={header}>
                                            {header}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        ))
                    ) : (
                        <p className="col-span-2 text-gray-500">Select a database table to see its columns for mapping.</p>
                    )}
                </div>

                <h4 className="text-lg font-semibold text-gray-700 mb-3">Data Preview (First 5 Rows)</h4>
                <div className="overflow-x-auto border border-gray-200 rounded-lg mb-6">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                        <tr>
                            {headers.map(header => (
                                <th key={header} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    {header}
                                </th>
                            ))}
                        </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                        {data.slice(0, 5).map((row, rowIndex) => (
                            <tr key={rowIndex}>
                                {headers.map(header => (
                                    <td key={`${rowIndex}-${header}`} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        {row[header]}
                                    </td>
                                ))}
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div>

                <div className="flex justify-end space-x-3">
                    <button onClick={onClose} className="px-5 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors shadow-sm">
                        Cancel
                    </button>
                    <button onClick={handleUpload} className="px-5 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed" disabled={uploadStatus === 'loading' || !selectedDatabase || targetColumns.length === 0}>
                        {uploadStatus === 'loading' ? 'Uploading...' : 'Upload Data'}
                    </button>
                </div>
            </div>
        </div>
    );
};

const MachinesTable = ({ onViewAlerts }) => {
    const [machines, setMachines] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [showUploadModal, setShowUploadModal] = useState(false);
    const [uploadedFileName, setUploadedFileName] = useState('');
    const [uploadedHeaders, setUploadedHeaders] = useState([]);
    const [uploadedData, setUploadedData] = useState([]);
    const [uploadedFileContent, setUploadedFileContent] = useState('');
    const [selectedDatabase, setSelectedDatabase] = useState('machines');
    const [selectedSeparator, setSelectedSeparator] = useState(';');
    const fileInputRef = React.useRef(null);

    // This useEffect is crucial for re-parsing data when the separator changes.
    useEffect(() => {
        if (uploadedFileContent && uploadedFileName.endsWith('.csv')) {
            const parsedData = parseCSV(uploadedFileContent, selectedSeparator);
            setUploadedHeaders(parsedData.headers);
            setUploadedData(parsedData.data);
        }
    }, [uploadedFileContent, selectedSeparator, uploadedFileName]);
    
    // ... other code for fetching machines ...

    const handleFileUploadClick = () => {
        fileInputRef.current.click();
    };

    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (!file) return;
        setUploadedFileName(file.name);
        const reader = new FileReader();

        reader.onload = (e) => {
            const content = e.target.result;
            setUploadedFileContent(content);
            let parsedData = { headers: [], data: [] };
            if (file.name.endsWith('.csv')) {
                parsedData = parseCSV(content, selectedSeparator);
            } else if (file.name.endsWith('.json')) {
                try {
                    const jsonContent = JSON.parse(content);
                    if (Array.isArray(jsonContent) && jsonContent.length > 0) {
                        parsedData.headers = Object.keys(jsonContent[0]);
                        parsedData.data = jsonContent;
                    } else {
                        setError('JSON file must contain an array of objects.');
                        return;
                    }
                } catch (jsonError) {
                    setError('Invalid JSON file.');
                    console.error('JSON parsing error:', jsonError);
                    return;
                }
            } else {
                setError('Unsupported file type. Please upload a .csv or .json file.');
                return;
            }

            setUploadedHeaders(parsedData.headers);
            setUploadedData(parsedData.data);
            setShowUploadModal(true);
        };
        reader.onerror = () => {
            setError('Failed to read file.');
        };
        reader.readAsText(file);
    };

    const handleUploadConfirm = async (dataToUpload, targetDatabase) => {
        try {
            const response = await fetch(
                `${SUPABASE_URL}/rest/v1/${targetDatabase}`,
                {
                    method: 'POST',
                    headers: {
                        'apikey': SUPABASE_KEY,
                        'Authorization': `Bearer ${SUPABASE_KEY}`,
                        'Content-Type': 'application/json',
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify(dataToUpload)
                }
            );

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Supabase upload failed: ${response.status} - ${errorText}`);
            }

            const result = await response.json();
            console.log('Upload successful:', result);
            if (targetDatabase === 'machines') {
                fetchMachines();
            }
            return { data: result, error: null };
        } catch (err) {
            console.error('Error uploading to Supabase:', err);
            return { data: null, error: err };
        }
    };

    // ... JSX render code for MachinesTable component ...

    return (
        <div className="p-6 max-w-6xl mx-auto">
            {/* ... other MachinesTable JSX ... */}
            <div className="flex gap-3">
                <button onClick={handleFileUploadClick} className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition-colors flex items-center gap-2">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                    </svg>
                    Upload File
                </button>
                <input type="file" ref={fileInputRef} onChange={handleFileChange} accept=".csv,.json" className="hidden" />
            </div>
            {/* ... other MachinesTable JSX ... */}
            <UploadModal
                isOpen={showUploadModal}
                onClose={() => setShowUploadModal(false)}
                headers={uploadedHeaders}
                data={uploadedData}
                onUploadConfirm={handleUploadConfirm}
                fileName={uploadedFileName}
                onDatabaseSelect={setSelectedDatabase}
                selectedDatabase={selectedDatabase}
                onSeparatorSelect={setSelectedSeparator}
                selectedSeparator={selectedSeparator}
            />
        </div>
    );
};

// Helper function to parse CSV data with a specified delimiter
const parseCSV = (text, delimiter = ',') => {
    const lines = text.trim().split('\n');
    if (lines.length === 0) return { headers: [], data: [] };

    const headers = lines[0].split(delimiter).map(h => h.trim());
    const data = lines.slice(1).map(line => {
        const values = line.split(delimiter).map(v => v.trim());
        const row = {};
        headers.forEach((header, index) => {
            row[header] = values[index];
        });
        return row;
    });
    return { headers, data };
};

// Define database schemas for mapping
const databaseSchemas = {
    machines: ['machine_id', 'machine_name', 'machine_location', 'machine_revenue'],
    inventory: ['item_id', 'item_name', 'quantity', 'last_restock_date'],
    transactions: ['transaction_id', 'machine_id', 'product_id', 'amount', 'timestamp'],
    maintenance_logs: ['log_id', 'machine_id', 'maintenance_date', 'description', 'technician'],
    machine_alerts_log: ['alert_log_id', 'machine_id', 'alert_name', 'start_time', 'end_time', 'severity'],
    machine_alerts_history: ['history_id', 'machine_id', 'alert_name', 'start_time', 'end_time', 'status'],
    deliveries: ['delivery_id', 'machine_id', 'delivery_date', 'items_delivered'],
    alerts: ['alert_id', 'machine_id', 'alert_name', 'alert_severity', 'start_time', 'resolved_time'],
};

