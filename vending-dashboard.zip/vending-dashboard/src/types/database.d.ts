// src/types/database.d.ts

export interface Machine {
  machine_id: string;
  machine_name: string;
  machine_location: string;
  machine_revenue: number;
  alert_id: number | null;
  created_at?: string | null;
  updated_at?: string | null;
  alerts: Alert | null;
}


export interface Alert {
  alert_id: number;
  alert_name: string;
  alert_severity: string; //"error" | "warning" | "offline" | "ok";
}

export interface MaintenanceLog {
  maintenance_id: string;
  machine_id: string;
  maintenance_type: string;
  notes?: string | null;
  performed_at: string;
  performed_by?: string | null;
}

export interface Product {
  inventory_id: string;
  machine_id: string;
  product_id: string;
  current_stock: number;
  capacity: number;
  position_id: string;
  created_at: string;
  product_name?: string;
}

export interface AlertWithMachine extends Alert {
  machine_id: string;
  machine_name: string;
}

export type MachineAlertLog = {
  machine_alert_id: string;
  machine_id: string;
  alert_id: number;
  start_time: string;
  resolved_time: string | null;
  notes: string;
  alerts: {
    alert_name: string;
    alert_severity: string;
  };
};
