// src/App.tsx
import { useEffect } from "react";
import { supabase } from "@/lib/supabaseClient";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import Dashboard from "@/pages/Dashboard";
import Login from "@/pages/Login";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import AuthListener from "@/components/AuthListener";
import MachineDetails from "@/pages/MachineDetails";
import MachineHistory from "@/pages/MachineHistory";
import Monitoring from "@/pages/Monitoring";



function App() {
  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      console.log("AUTH CHANGE:", event, session);
    });

    return () => subscription.unsubscribe();
  }, []);

  return (
    <BrowserRouter>
      <AuthListener />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
            path="/monitoring"
            element={
              <ProtectedRoute>
                <Monitoring />
              </ProtectedRoute>
            }
          />
        <Route 
            path="/machine/:machine_id" 
            element={
            <ProtectedRoute>
              <MachineDetails />
            </ProtectedRoute>
            }
          />
        <Route
            path="/machine/:id/history"
            element={
              <ProtectedRoute>
                <MachineHistory />
              </ProtectedRoute>
            }
          />
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
