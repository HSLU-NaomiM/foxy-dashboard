// src/pages/Dashboard.tsx
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { VendingMachinesTable } from "@/components/VendingMachinesTable";
import { AlertsTable } from "@/components/AlertsTable";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import type { Machine, Alert } from "@/types/database";
import { Icon } from "lucide-react";
import { foxFaceTail } from "@lucide/lab";

export default function Dashboard() {
  const [machines, setMachines] = useState<Machine[]>([]);
  const [alerts, setAlerts] = useState<(Alert & { machine_name?: string })[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      setLoading(true);

      const { data: machinesData, error: machinesError } = await supabase
        .from("machines")
        .select(`
          machine_id,
          machine_name,
          machine_location,
          machine_revenue,
          alert_id,
          alerts (alert_id, alert_name, alert_severity)
        `);

      if (machinesError) throw machinesError;

      const flatMachines = machinesData.map((m: any) => ({
        ...m,
        alert: m.alerts || null,
      }));

      setMachines(flatMachines);

      const { data: alertsData, error: alertsError } = await supabase
        .from("alerts")
        .select("*");

      if (alertsError) throw alertsError;

      const enrichedAlerts = alertsData.map((alert) => {
        const match = flatMachines.find((m) => m.alert_id === alert.alert_id);
        return {
          ...alert,
          machine_name: match?.machine_name || "Unknown",
        };
      });

      setAlerts(enrichedAlerts);
    } catch (err) {
      console.error("Error fetching data:", err);
      setError("Failed to load data. Check your Supabase setup.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();

    const channel = supabase
      .channel("dashboard-listeners")
      .on("postgres_changes", { event: "*", schema: "public", table: "machines" }, () => fetchData())
      .on("postgres_changes", { event: "*", schema: "public", table: "alerts" }, () => fetchData())
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100 p-6 md:p-10 font-inter">
      <div className="max-w-7xl mx-auto space-y-8">
        <header className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <Icon iconNode={foxFaceTail} className="w-10 h-10 text-zinc-800 dark:text-zinc-100" />
            <h1 className="text-4xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100 sm:text-5xl">
              Vending Machine Dashboard
            </h1>
          </div>
          <button
            className="text-sm text-red-600 hover:underline"
            onClick={() => supabase.auth.signOut()}
          >
            Logout
          </button>
        </header>

        <main className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-2xl shadow-lg p-4">
            <CardHeader>
              <CardTitle className="text-xl font-bold">Vending Machines</CardTitle>
              <CardDescription>
                A list of all active vending machines and their status.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading && <div className="p-4 text-center text-gray-500">Loading...</div>}
              {error && <div className="p-4 text-center text-red-500">{error}</div>}
              {!loading && !error && machines.length > 0 ? (
                <VendingMachinesTable machines={machines} />
              ) : (
                !loading && !error && <div className="p-4 text-center text-gray-500">No machines found.</div>
              )}
            </CardContent>
          </Card>

          <Card className="rounded-xl shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-bold">Alerts</CardTitle>
              <CardDescription>
                Active alerts and issues that require attention.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading && <div className="p-4 text-center text-gray-500">Loading...</div>}
              {error && <div className="p-4 text-center text-red-500">{error}</div>}
              {!loading && !error && alerts.length > 0 ? (
                <AlertsTable alerts={alerts} />
              ) : (
                !loading && !error && <div className="p-4 text-center text-gray-500">No alerts found.</div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}