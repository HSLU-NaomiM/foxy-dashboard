// src/pages/MachineDetails.tsx
import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/lib/supabaseClient";
import type { MaintenanceLog, Product } from "@/types/database";

export default function MachineDetails() {
  const { machine_id } = useParams<{ machine_id: string }>();
  const [machine, setMachine] = useState<any | null>(null);
  const [maintenance, setMaintenance] = useState<MaintenanceLog | null>(null);
  const [inventory, setInventory] = useState<(Product & { product_name: string })[]>([]);
  const [alertLogs, setAlertLogs] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!machine_id) return;

    const fetchDetails = async () => {
      try {
        const { data: machinesData, error: machineError } = await supabase
          .from("machines")
          .select("*")
          .eq("machine_id", machine_id)
          .single();

        if (machineError) throw machineError;
        setMachine(machinesData);

        const { data: alertsLogData, error: alertsLogError } = await supabase
          .from("machine_alerts_log")
          .select(`
            machine_alert_id,
            start_time,
            resolved_time,
            notes,
            alerts (
              alert_name,
              alert_severity
            )
          `)
          .eq("machine_id", machine_id)
          .order("start_time", { ascending: false });

        if (alertsLogError) throw alertsLogError;
        setAlertLogs(alertsLogData);

      } catch (error: any) {
        setError(error.message);
      }
    };

    fetchDetails();
  }, [machine_id]);

  const getSeverityClass = (severity: string) => {
    switch (severity) {
      case "critical":
        return "text-red-700 bg-red-100";
      case "high":
      case "error":
        return "text-orange-700 bg-orange-100";
      case "warning":
        return "text-yellow-800 bg-yellow-100";
      case "offline":
        return "text-gray-700 bg-gray-200";
      case "ok":
        return "text-green-700 bg-green-100";
      default:
        return "text-gray-600";
    }
  };

  return (
    <div className="p-4">
      {machine ? (
        <>
          <h1 className="text-xl font-bold mb-4">{machine.machine_name}</h1>
          <p className="text-sm text-gray-600 mb-2">{machine.machine_location}</p>
          <p className="text-sm text-gray-800 font-medium mb-4">Umsatz: CHF {machine.machine_revenue.toFixed(2)}</p>

          {alertLogs.length > 0 ? (
            <div className="mt-6">
              <h2 className="text-lg font-semibold mb-2">Störungsmeldungen</h2>
              <table className="w-full text-left border">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="p-2">Beginn</th>
                    <th className="p-2">Beendet</th>
                    <th className="p-2">Typ</th>
                    <th className="p-2">Schwere</th>
                    <th className="p-2">Notiz</th>
                  </tr>
                </thead>
                <tbody>
                  {alertLogs.map((entry) => (
                    <tr key={entry.machine_alert_id} className="border-t">
                      <td className="p-2">{new Date(entry.start_time).toLocaleString()}</td>
                      <td className="p-2">
                        {entry.resolved_time
                          ? new Date(entry.resolved_time).toLocaleString()
                          : "❗ Offen"}
                      </td>
                      <td className="p-2">{entry.alerts?.alert_name || "-"}</td>
                      <td className={`p-2 font-medium rounded ${getSeverityClass(entry.alerts?.alert_severity || "")}`}>
                        {entry.alerts?.alert_severity || "-"}
                      </td>
                      <td className="p-2">{entry.notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="mt-6 text-sm text-gray-600">Keine Störmeldungen gefunden 🎉</p>
          )}
        </>
      ) : (
        <p>Lade Maschinendetails...</p>
      )}

      {error && <p className="text-red-500 mt-4">Fehler: {error}</p>}
    </div>
  );
}
